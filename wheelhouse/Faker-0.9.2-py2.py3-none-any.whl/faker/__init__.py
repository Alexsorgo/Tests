from faker.generator import Generator  # noqa F401
from faker.factory import Factory  # noqa F401

VERSION = '0.9.2'

Faker = Factory.create
